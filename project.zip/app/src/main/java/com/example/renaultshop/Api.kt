package com.example.renaultshop

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

data class ProductImage(val src: String?)

data class ProductPrices(
    val price: String?,
    val currency_minor_unit: Int?,
    val currency_symbol: String?
)

data class Product(
    val id: Int,
    val name: String,
    val prices: ProductPrices?,
    val images: List<ProductImage>?
)

interface StoreApi {
    @GET("wp-json/wc/store/v1/products")
    suspend fun getProducts(
        @Query("per_page") perPage: Int = 20,
        @Query("page") page: Int = 1
    ): List<Product>
}

object ApiClient {
    // آدرس سایت از فایل site_url.txt توسط GitHub جایگزین میشه
    private const val BASE_URL = "https://yoursite.com/"

    val api: StoreApi = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(StoreApi::class.java)
}
